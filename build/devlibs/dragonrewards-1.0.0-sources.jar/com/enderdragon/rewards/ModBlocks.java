package com.enderdragon.rewards;

import com.enderdragon.rewards.block.RewardChestBlock;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModBlocks {
    public static final Block REWARD_CHEST = new RewardChestBlock(AbstractBlock.Settings.create()
        .mapColor(MapColor.BLACK)
        .strength(-1.0f, 3600000.0f)
        .pistonBehavior(PistonBehavior.BLOCK)
        .nonOpaque());

    public static void init() {
        Registry.register(Registries.BLOCK, Identifier.of(DragonRewardsMod.MOD_ID, "reward_chest"), REWARD_CHEST);
        Registry.register(Registries.ITEM, Identifier.of(DragonRewardsMod.MOD_ID, "reward_chest"), new BlockItem(REWARD_CHEST, new Item.Settings()));
    }
}
