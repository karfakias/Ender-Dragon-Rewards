package com.enderdragon.rewards;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;
import net.minecraft.world.PersistentStateManager;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class RewardState extends PersistentState {
    public static final String KEY = "dragonrewards_state";
    private static final PersistentState.Type<RewardState> TYPE = new PersistentState.Type<>(
        RewardState::new,
        RewardState::fromNbt,
        null
    );

    private double currentElytraChance;
    private double currentDragonHeadChance;

    private final List<ActiveRewardChest> activeChests = new ArrayList<>();
    private final Set<UUID> processedDragonIds = new LinkedHashSet<>();

    public RewardState() {
        this.currentElytraChance = DragonRewardsMod.CONFIG.elytraBaseChance;
        this.currentDragonHeadChance = DragonRewardsMod.CONFIG.dragonHeadBaseChance;
    }

    public static RewardState get(MinecraftServer server) {
        PersistentStateManager manager = server.getWorld(World.OVERWORLD).getPersistentStateManager();
        return manager.getOrCreate(TYPE, KEY);
    }

    public static RewardState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
        RewardState state = new RewardState();
        state.currentElytraChance = nbt.getDouble("CurrentElytraChance");
        state.currentDragonHeadChance = nbt.getDouble("CurrentDragonHeadChance");

        NbtList chestList = nbt.getList("ActiveChests", NbtCompound.COMPOUND_TYPE);
        for (int i = 0; i < chestList.size(); i++) {
            state.activeChests.add(ActiveRewardChest.fromNbt(chestList.getCompound(i)));
        }

        NbtList processed = nbt.getList("ProcessedDragonIds", NbtString.STRING_TYPE);
        for (int i = 0; i < processed.size(); i++) {
            try {
                state.processedDragonIds.add(UUID.fromString(processed.getString(i)));
            } catch (IllegalArgumentException ignored) {
            }
        }

        state.sanitize();
        return state;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
        nbt.putDouble("CurrentElytraChance", currentElytraChance);
        nbt.putDouble("CurrentDragonHeadChance", currentDragonHeadChance);

        NbtList chestList = new NbtList();
        for (ActiveRewardChest chest : activeChests) {
            chestList.add(chest.toNbt());
        }
        nbt.put("ActiveChests", chestList);

        NbtList processed = new NbtList();
        for (UUID uuid : processedDragonIds) {
            processed.add(NbtString.of(uuid.toString()));
        }
        nbt.put("ProcessedDragonIds", processed);
        return nbt;
    }

    public double getCurrentElytraChance() {
        return currentElytraChance;
    }

    public void setCurrentElytraChance(double currentElytraChance) {
        this.currentElytraChance = currentElytraChance;
        sanitize();
        markDirty();
    }

    public double getCurrentDragonHeadChance() {
        return currentDragonHeadChance;
    }

    public void setCurrentDragonHeadChance(double currentDragonHeadChance) {
        this.currentDragonHeadChance = currentDragonHeadChance;
        sanitize();
        markDirty();
    }

    public List<ActiveRewardChest> getActiveChests() {
        return activeChests;
    }

    public void addChest(ActiveRewardChest chest) {
        this.activeChests.add(chest);
        markDirty();
    }

    public void updateChest(ActiveRewardChest updated) {
        for (int i = 0; i < activeChests.size(); i++) {
            if (activeChests.get(i).chestPos().equals(updated.chestPos())) {
                activeChests.set(i, updated);
                markDirty();
                return;
            }
        }
    }

    public void removeChestAt(net.minecraft.util.math.BlockPos pos) {
        activeChests.removeIf(chest -> chest.chestPos().equals(pos));
        markDirty();
    }

    public boolean isDragonProcessed(UUID dragonUuid) {
        return processedDragonIds.contains(dragonUuid);
    }

    public void markDragonProcessed(UUID dragonUuid) {
        processedDragonIds.add(dragonUuid);
        while (processedDragonIds.size() > 256) {
            UUID oldest = processedDragonIds.iterator().next();
            processedDragonIds.remove(oldest);
        }
        markDirty();
    }

    public int getProcessedDragonCount() {
        return processedDragonIds.size();
    }

    public void clearProcessedDragons() {
        processedDragonIds.clear();
        markDirty();
    }

    public void sanitize() {
        currentElytraChance = clamp(currentElytraChance, DragonRewardsMod.CONFIG.elytraBaseChance, DragonRewardsMod.CONFIG.elytraMaxChance);
        currentDragonHeadChance = clamp(currentDragonHeadChance, DragonRewardsMod.CONFIG.dragonHeadBaseChance, DragonRewardsMod.CONFIG.dragonHeadMaxChance);
    }

    private static double clamp(double value, double min, double max) {
        if (max < min) {
            max = min;
        }
        return Math.max(min, Math.min(max, value));
    }
}
