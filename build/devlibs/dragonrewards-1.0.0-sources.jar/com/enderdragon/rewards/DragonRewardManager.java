package com.enderdragon.rewards;

import com.enderdragon.rewards.block.entity.RewardChestBlockEntity;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

public final class DragonRewardManager {
    private DragonRewardManager() {
    }

    public static void init() {
        ServerLivingEntityEvents.AFTER_DEATH.register(DragonRewardManager::onEntityDeath);

        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (world.isClient()) {
                return true;
            }
            if (state.isOf(ModBlocks.REWARD_CHEST)) {
                player.sendMessage(Text.literal("Reward chests cannot be broken."), false);
                return false;
            }
            return true;
        });

        ServerLifecycleEvents.SERVER_STARTED.register(DragonRewardManager::reconcilePersistentChests);
    }

    private static void onEntityDeath(LivingEntity entity, DamageSource damageSource) {
        if (!(entity instanceof EnderDragonEntity dragon)) {
            return;
        }
        if (!(entity.getWorld() instanceof ServerWorld world) || world.getRegistryKey() != World.END) {
            return;
        }

        RewardState state = RewardState.get(world.getServer());
        UUID dragonUuid = dragon.getUuid();
        if (state.isDragonProcessed(dragonUuid)) {
            debug(world.getServer(), "Skipped duplicate dragon death event for " + dragonUuid);
            return;
        }
        state.markDragonProcessed(dragonUuid);

        OwnerData owner = resolveOwnerData(dragon, damageSource, world);

        boolean rolledElytra = false;
        boolean rolledHead = false;
        List<ItemStack> rewards = new ArrayList<>();

        if (DragonRewardsMod.CONFIG.enableElytraDrops) {
            rolledElytra = world.random.nextDouble() < state.getCurrentElytraChance();
            if (rolledElytra) {
                rewards.add(new ItemStack(Items.ELYTRA));
                state.setCurrentElytraChance(DragonRewardsMod.CONFIG.elytraBaseChance);
            } else {
                state.setCurrentElytraChance(Math.min(
                    DragonRewardsMod.CONFIG.elytraMaxChance,
                    state.getCurrentElytraChance() + DragonRewardsMod.CONFIG.elytraFailureIncrement
                ));
            }
        }

        if (DragonRewardsMod.CONFIG.enableDragonHeadDrops) {
            rolledHead = world.random.nextDouble() < state.getCurrentDragonHeadChance();
            if (rolledHead) {
                rewards.add(new ItemStack(Items.DRAGON_HEAD));
                state.setCurrentDragonHeadChance(DragonRewardsMod.CONFIG.dragonHeadBaseChance);
            } else {
                state.setCurrentDragonHeadChance(Math.min(
                    DragonRewardsMod.CONFIG.dragonHeadMaxChance,
                    state.getCurrentDragonHeadChance() + DragonRewardsMod.CONFIG.dragonHeadFailureIncrement
                ));
            }
        }

        if (!rewards.isEmpty()) {
            BlockPos chestPos = findChestSpawnPosition(world, state);
            createRewardChest(world, state, chestPos, owner, rewards);
        }

        broadcastOutcome(world.getServer(), owner.playerName(), rolledElytra, rolledHead);
    }

    private static void createRewardChest(ServerWorld world, RewardState state, BlockPos chestPos, OwnerData owner, List<ItemStack> rewards) {
        world.setBlockState(chestPos, ModBlocks.REWARD_CHEST.getDefaultState(), Block.NOTIFY_ALL);
        if (world.getBlockEntity(chestPos) instanceof RewardChestBlockEntity chestEntity) {
            chestEntity.setOwner(owner.playerUuid(), owner.playerName());
            for (int i = 0; i < rewards.size() && i < chestEntity.size(); i++) {
                chestEntity.setStack(i, rewards.get(i).copy());
            }
        }

        UUID markerUuid = spawnNameMarker(world, chestPos, owner.playerName());
        state.addChest(new ActiveRewardChest(owner.playerUuid(), owner.playerName(), chestPos, markerUuid));

        debug(world.getServer(), "Spawned reward chest for " + owner.playerName() + " at " + chestPos.toShortString());
    }

    public static BlockPos spawnManualRewardChest(ServerWorld world, ServerPlayerEntity owner, boolean includeElytra, boolean includeDragonHead) {
        if (!includeElytra && !includeDragonHead) {
            return null;
        }

        RewardState state = RewardState.get(world.getServer());
        BlockPos chestPos = findChestSpawnPosition(world, state);
        List<ItemStack> rewards = new ArrayList<>();
        if (includeElytra) {
            rewards.add(new ItemStack(Items.ELYTRA));
        }
        if (includeDragonHead) {
            rewards.add(new ItemStack(Items.DRAGON_HEAD));
        }

        OwnerData ownerData = new OwnerData(owner.getUuid(), owner.getName().getString());
        createRewardChest(world, state, chestPos, ownerData, rewards);
        return chestPos;
    }

    public static boolean removeManagedChest(ServerWorld world, BlockPos pos) {
        RewardState state = RewardState.get(world.getServer());
        Optional<ActiveRewardChest> chest = state.getActiveChests().stream()
            .filter(active -> active.chestPos().equals(pos))
            .findFirst();

        if (chest.isEmpty()) {
            return false;
        }

        removeMarker(world, chest.get().markerUuid());
        state.removeChestAt(pos);
        if (world.getBlockState(pos).isOf(ModBlocks.REWARD_CHEST)) {
            world.removeBlock(pos, false);
        }
        return true;
    }

    public static int removeAllManagedChests(ServerWorld world) {
        RewardState state = RewardState.get(world.getServer());
        List<ActiveRewardChest> snapshot = new ArrayList<>(state.getActiveChests());
        for (ActiveRewardChest chest : snapshot) {
            removeMarker(world, chest.markerUuid());
            if (world.getBlockState(chest.chestPos()).isOf(ModBlocks.REWARD_CHEST)) {
                world.removeBlock(chest.chestPos(), false);
            }
            state.removeChestAt(chest.chestPos());
        }
        return snapshot.size();
    }

    public static void onRewardChestEmptied(ServerWorld world, BlockPos pos) {
        RewardState state = RewardState.get(world.getServer());
        Optional<ActiveRewardChest> chest = state.getActiveChests().stream()
            .filter(active -> active.chestPos().equals(pos))
            .findFirst();

        chest.ifPresent(active -> {
            removeMarker(world, active.markerUuid());
            state.removeChestAt(pos);
            world.removeBlock(pos, false);
            debug(world.getServer(), "Removed emptied reward chest at " + pos.toShortString());
        });
    }

    public static void reconcilePersistentChests(MinecraftServer server) {
        ServerWorld end = server.getWorld(World.END);
        if (end == null) {
            return;
        }

        RewardState state = RewardState.get(server);
        List<ActiveRewardChest> snapshot = new ArrayList<>(state.getActiveChests());
        for (ActiveRewardChest chest : snapshot) {
            BlockPos pos = chest.chestPos();
            BlockState blockState = end.getBlockState(pos);
            if (!blockState.isOf(ModBlocks.REWARD_CHEST)) {
                removeMarker(end, chest.markerUuid());
                state.removeChestAt(pos);
                continue;
            }

            if (end.getBlockEntity(pos) instanceof RewardChestBlockEntity blockEntity) {
                blockEntity.setOwner(chest.ownerUuid(), chest.ownerName());
            }

            Entity marker = chest.markerUuid() == null ? null : end.getEntity(chest.markerUuid());
            if (!(marker instanceof ArmorStandEntity)) {
                UUID newMarker = spawnNameMarker(end, pos, chest.ownerName());
                state.updateChest(chest.withMarker(newMarker));
            }
        }
    }

    private static OwnerData resolveOwnerData(EnderDragonEntity dragon, DamageSource source, ServerWorld world) {
        UUID uuid = null;
        String name = "Unknown";

        if (dragon instanceof DragonDamageTracker tracker) {
            uuid = tracker.dragonrewards$getLastDamagerUuid();
            String trackedName = tracker.dragonrewards$getLastDamagerName();
            if (trackedName != null && !trackedName.isBlank()) {
                name = trackedName;
            }
        }

        if (uuid == null) {
            Entity attacker = source.getAttacker();
            if (attacker instanceof ServerPlayerEntity serverPlayer) {
                uuid = serverPlayer.getUuid();
                name = serverPlayer.getName().getString();
            }
        }

        if (uuid == null) {
            ServerPlayerEntity fallback = world.getPlayers().stream()
                .min((a, b) -> Double.compare(a.squaredDistanceTo(dragon), b.squaredDistanceTo(dragon)))
                .orElse(null);
            if (fallback != null) {
                uuid = fallback.getUuid();
                name = fallback.getName().getString();
            }
        }

        if (uuid == null) {
            uuid = new UUID(0L, 0L);
        }

        return new OwnerData(uuid, name);
    }

    private static void broadcastOutcome(MinecraftServer server, String playerName, boolean elytra, boolean dragonHead) {
        String template;
        if (elytra && dragonHead) {
            template = DragonRewardsMod.CONFIG.messages.bothDropped;
        } else if (elytra) {
            template = DragonRewardsMod.CONFIG.messages.onlyElytra;
        } else if (dragonHead) {
            template = DragonRewardsMod.CONFIG.messages.onlyDragonHead;
        } else {
            template = DragonRewardsMod.CONFIG.messages.nothingDropped;
        }

        server.getPlayerManager().broadcast(Text.literal(template.replace("{player}", playerName)), false);
    }

    private static BlockPos findChestSpawnPosition(ServerWorld world, RewardState state) {
        BlockPos portalCenter = findExitPortalCenter(world);
        int portalTargetY = portalCenter.getY() + DragonRewardsMod.CONFIG.chestYOffsetFromPortal;
        Set<BlockPos> occupied = new HashSet<>();
        for (ActiveRewardChest active : state.getActiveChests()) {
            occupied.add(active.chestPos());
        }

        int radius = Math.max(1, DragonRewardsMod.CONFIG.chestSpawnRadius);
        for (int ring = 0; ring <= radius; ring++) {
            if (ring == 0) {
                BlockPos pos = resolvePortalHeight(world, portalCenter, portalTargetY);
                if (!occupied.contains(pos) && isValidChestSpot(world, pos)) {
                    return pos;
                }
                continue;
            }

            for (int dx = -ring; dx <= ring; dx++) {
                for (int dz = -ring; dz <= ring; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != ring) {
                        continue;
                    }

                    BlockPos offset = portalCenter.add(dx, 0, dz);
                    BlockPos candidate = resolvePortalHeight(world, offset, portalTargetY);
                    if (!occupied.contains(candidate) && isValidChestSpot(world, candidate)) {
                        return candidate;
                    }
                }
            }
        }

        // Guaranteed fallback, clamped to build limits.
        int y = MathHelper.clamp(portalCenter.getY() + DragonRewardsMod.CONFIG.chestYOffsetFromPortal, world.getBottomY() + 1, world.getTopY() - 2);
        BlockPos fallback = new BlockPos(portalCenter.getX(), y, portalCenter.getZ());
        while (occupied.contains(fallback) || !isValidChestSpot(world, fallback)) {
            fallback = fallback.up();
            if (fallback.getY() >= world.getTopY() - 1) {
                return fallback.down();
            }
        }
        return fallback;
    }

    private static BlockPos resolvePortalHeight(ServerWorld world, BlockPos xzPos, int targetY) {
        int y = MathHelper.clamp(targetY, world.getBottomY() + 1, world.getTopY() - 2);
        BlockPos pos = new BlockPos(xzPos.getX(), y, xzPos.getZ());

        if (!world.getBlockState(pos).isAir() || !world.getBlockState(pos.up()).isAir()) {
            int top = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, xzPos.getX(), xzPos.getZ());
            y = MathHelper.clamp(top + 1, world.getBottomY() + 1, world.getTopY() - 2);
            pos = new BlockPos(xzPos.getX(), y, xzPos.getZ());
        }
        return pos;
    }

    private static boolean isValidChestSpot(ServerWorld world, BlockPos pos) {
        return world.getBlockState(pos).isAir()
            && world.getBlockState(pos.up()).isAir()
            && world.getBlockState(pos.down()).isSolidBlock(world, pos.down());
    }

    private static BlockPos findExitPortalCenter(ServerWorld world) {
        int minX = -16;
        int maxX = 16;
        int minZ = -16;
        int maxZ = 16;
        int minY = 40;
        int maxY = 100;

        int count = 0;
        long sumX = 0;
        long sumY = 0;
        long sumZ = 0;

        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                for (int y = minY; y <= maxY; y++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    if (world.getBlockState(pos).isOf(Blocks.END_PORTAL)) {
                        count++;
                        sumX += x;
                        sumY += y;
                        sumZ += z;
                    }
                }
            }
        }

        if (count > 0) {
            return new BlockPos(
                Math.toIntExact(sumX / count),
                Math.toIntExact(sumY / count),
                Math.toIntExact(sumZ / count)
            );
        }

        int top = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, 0, 0);
        return new BlockPos(0, top, 0);
    }

    private static UUID spawnNameMarker(ServerWorld world, BlockPos chestPos, String ownerName) {
        ArmorStandEntity marker = EntityType.ARMOR_STAND.create(world);
        if (marker == null) {
            return null;
        }

        marker.setPosition(chestPos.getX() + 0.5, chestPos.getY() + 1.35, chestPos.getZ() + 0.5);
        marker.setInvisible(true);
        marker.setNoGravity(true);
        marker.setCustomNameVisible(true);
        marker.setCustomName(Text.literal(ownerName + "'s Rewards"));
        marker.setInvulnerable(true);

        world.spawnEntity(marker);
        return marker.getUuid();
    }

    private static void removeMarker(ServerWorld world, UUID markerUuid) {
        if (markerUuid == null) {
            return;
        }
        Entity entity = world.getEntity(markerUuid);
        if (entity != null) {
            entity.discard();
        }
    }

    private static void debug(MinecraftServer server, String message) {
        if (DragonRewardsMod.CONFIG.debugMode) {
            DragonRewardsMod.LOGGER.info("[debug] {}", message);
        }
    }

    private record OwnerData(UUID playerUuid, String playerName) {
    }
}
