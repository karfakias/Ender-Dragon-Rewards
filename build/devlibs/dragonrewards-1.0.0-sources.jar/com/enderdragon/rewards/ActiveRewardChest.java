package com.enderdragon.rewards;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;

import java.util.UUID;

public record ActiveRewardChest(UUID ownerUuid, String ownerName, BlockPos chestPos, UUID markerUuid) {
    public NbtCompound toNbt() {
        NbtCompound nbt = new NbtCompound();
        nbt.putUuid("OwnerUuid", ownerUuid);
        nbt.putString("OwnerName", ownerName);
        nbt.putIntArray("ChestPos", new int[]{chestPos.getX(), chestPos.getY(), chestPos.getZ()});
        if (markerUuid != null) {
            nbt.putUuid("MarkerUuid", markerUuid);
        }
        return nbt;
    }

    public static ActiveRewardChest fromNbt(NbtCompound nbt) {
        int[] posArray = nbt.getIntArray("ChestPos");
        Vec3i vec = posArray.length == 3 ? new Vec3i(posArray[0], posArray[1], posArray[2]) : Vec3i.ZERO;
        UUID marker = nbt.containsUuid("MarkerUuid") ? nbt.getUuid("MarkerUuid") : null;
        return new ActiveRewardChest(
            nbt.getUuid("OwnerUuid"),
            nbt.getString("OwnerName"),
            new BlockPos(vec),
            marker
        );
    }

    public ActiveRewardChest withMarker(UUID newMarker) {
        return new ActiveRewardChest(ownerUuid, ownerName, chestPos, newMarker);
    }
}
