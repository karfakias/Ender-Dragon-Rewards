package com.enderdragon.rewards;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_4844;

public record ActiveRewardChest(UUID ownerUuid, String ownerName, class_2338 chestPos, UUID markerUuid, List<class_1799> rewards, long expiresAtTick) {
    public static final Codec<ActiveRewardChest> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        class_4844.field_40825.fieldOf("ownerUuid").forGetter(ActiveRewardChest::ownerUuid),
        Codec.STRING.fieldOf("ownerName").forGetter(ActiveRewardChest::ownerName),
        class_2338.field_25064.fieldOf("chestPos").forGetter(ActiveRewardChest::chestPos),
        class_4844.field_40825.optionalFieldOf("markerUuid").forGetter(chest -> Optional.ofNullable(chest.markerUuid())),
        class_1799.field_49266.listOf().optionalFieldOf("rewards", List.of()).forGetter(ActiveRewardChest::rewards),
        Codec.LONG.optionalFieldOf("expiresAtTick", 0L).forGetter(ActiveRewardChest::expiresAtTick)
    ).apply(instance, (ownerUuid, ownerName, chestPos, markerUuid, rewards, expiresAtTick) -> new ActiveRewardChest(ownerUuid, ownerName, chestPos, markerUuid.orElse(null), new ArrayList<>(rewards), expiresAtTick)));

    public ActiveRewardChest withMarker(UUID newMarker) {
        return new ActiveRewardChest(ownerUuid, ownerName, chestPos, newMarker, new ArrayList<>(rewards), expiresAtTick);
    }

    public ActiveRewardChest withRewards(List<class_1799> newRewards) {
        return new ActiveRewardChest(ownerUuid, ownerName, chestPos, markerUuid, new ArrayList<>(newRewards), expiresAtTick);
    }
}
