package com.enderdragon.rewards;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_11560;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public final class DragonRewardsCommands {
    private DragonRewardsCommands() {
    }

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
            method_9247("dragonrewards")
                .then(method_9247("help").executes(DragonRewardsCommands::help))
                .then(method_9247("status").executes(DragonRewardsCommands::status))
                .then(method_9247("reload").executes(DragonRewardsCommands::reloadConfig))
                .then(method_9247("save").executes(DragonRewardsCommands::saveConfig))
                .then(method_9247("debug")
                    .then(method_9244("enabled", BoolArgumentType.bool())
                        .executes(DragonRewardsCommands::setDebug)))
                .then(method_9247("feature")
                    .then(method_9247("elytra")
                        .then(method_9244("enabled", BoolArgumentType.bool())
                            .executes(ctx -> setFeature(ctx, true))))
                    .then(method_9247("dragon_head")
                        .then(method_9244("enabled", BoolArgumentType.bool())
                            .executes(ctx -> setFeature(ctx, false)))))
                .then(method_9247("chance")
                    .then(method_9247("get").executes(DragonRewardsCommands::chanceGet))
                    .then(method_9247("reset")
                        .executes(ctx -> chanceReset(ctx, true, true))
                        .then(method_9247("elytra").executes(ctx -> chanceReset(ctx, true, false)))
                        .then(method_9247("dragon_head").executes(ctx -> chanceReset(ctx, false, true))))
                    .then(method_9247("set")
                        .then(method_9247("elytra")
                            .then(method_9244("value", DoubleArgumentType.doubleArg(0.0, 1.0))
                                .executes(ctx -> chanceSet(ctx, true))))
                        .then(method_9247("dragon_head")
                            .then(method_9244("value", DoubleArgumentType.doubleArg(0.0, 1.0))
                                .executes(ctx -> chanceSet(ctx, false)))))
                    .then(method_9247("add")
                        .then(method_9247("elytra")
                            .then(method_9244("delta", DoubleArgumentType.doubleArg(-1.0, 1.0))
                                .executes(ctx -> chanceAdd(ctx, true))))
                        .then(method_9247("dragon_head")
                            .then(method_9244("delta", DoubleArgumentType.doubleArg(-1.0, 1.0))
                                .executes(ctx -> chanceAdd(ctx, false)))))
                    .then(method_9247("simulate")
                        .then(method_9244("kills", IntegerArgumentType.integer(1, 10000))
                            .executes(DragonRewardsCommands::simulate))))
                .then(method_9247("chests")
                    .then(method_9247("list").executes(DragonRewardsCommands::listChests))
                    .then(method_9247("cleanup").executes(DragonRewardsCommands::cleanupChests))
                    .then(method_9247("clear").executes(DragonRewardsCommands::clearChests))
                    .then(method_9247("time")
                        .then(method_9244("minutes", IntegerArgumentType.integer(1, 1440))
                            .executes(DragonRewardsCommands::setChestTime)))
                    .then(method_9247("delay")
                        .then(method_9244("seconds", IntegerArgumentType.integer(0, 600))
                            .executes(DragonRewardsCommands::setChestDelay)))
                    .then(method_9247("remove")
                        .then(method_9244("x", IntegerArgumentType.integer())
                            .then(method_9244("y", IntegerArgumentType.integer())
                                .then(method_9244("z", IntegerArgumentType.integer())
                                    .executes(DragonRewardsCommands::removeChestAt)))))
                    .then(method_9247("spawn")
                        .then(class_2170.method_9244("player", net.minecraft.class_2186.method_9305())
                            .then(method_9244("elytra", BoolArgumentType.bool())
                                .then(method_9244("dragon_head", BoolArgumentType.bool())
                                    .executes(DragonRewardsCommands::spawnChest))))))
                .then(method_9247("processed")
                    .then(method_9247("count").executes(DragonRewardsCommands::processedCount))
                    .then(method_9247("clear").executes(DragonRewardsCommands::clearProcessed))))
        );
    }

    private static boolean hasAdminPermission(class_2168 source) {
        if (!source.method_43737()) {
            return true;
        }
        class_3222 player = source.method_44023();
        if (player == null) {
            return false;
        }
        return source.method_9211().method_3760().method_14569(new class_11560(player.method_7334()));
    }

    private static boolean ensureAdmin(class_2168 source) {
        if (hasAdminPermission(source)) {
            return true;
        }
        source.method_9213(class_2561.method_43470("You must be an operator to use /dragonrewards."));
        return false;
    }

    private static int help(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        if (!ensureAdmin(src)) {
            return 0;
        }
        send(src, "/dragonrewards status");
        send(src, "/dragonrewards reload");
        send(src, "/dragonrewards save");
        send(src, "/dragonrewards debug <true|false>");
        send(src, "/dragonrewards feature elytra <true|false>");
        send(src, "/dragonrewards feature dragon_head <true|false>");
        send(src, "/dragonrewards chance get");
        send(src, "/dragonrewards chance reset [elytra|dragon_head]");
        send(src, "/dragonrewards chance set <elytra|dragon_head> <0..1>");
        send(src, "/dragonrewards chance add <elytra|dragon_head> <-1..1>");
        send(src, "/dragonrewards chance simulate <kills>");
        send(src, "/dragonrewards chests list");
        send(src, "/dragonrewards chests cleanup");
        send(src, "/dragonrewards chests clear");
        send(src, "/dragonrewards chests time <minutes>");
        send(src, "/dragonrewards chests delay <seconds>");
        send(src, "/dragonrewards chests remove <x> <y> <z>");
        send(src, "/dragonrewards chests spawn <player> <elytra:true|false> <dragon_head:true|false>");
        send(src, "/dragonrewards processed count");
        send(src, "/dragonrewards processed clear");
        return 1;
    }

    private static int status(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        if (!ensureAdmin(src)) {
            return 0;
        }
        RewardState state = RewardState.get(src.method_9211());
        send(src, "DragonRewards status:");
        send(src, " Elytra: enabled=" + DragonRewardsMod.CONFIG.enableElytraDrops + ", current=" + pct(state.getCurrentElytraChance()) + ", base=" + pct(DragonRewardsMod.CONFIG.elytraBaseChance) + ", inc=" + pct(DragonRewardsMod.CONFIG.elytraFailureIncrement) + ", cap=" + pct(DragonRewardsMod.CONFIG.elytraMaxChance));
        send(src, " Dragon Head: enabled=" + DragonRewardsMod.CONFIG.enableDragonHeadDrops + ", current=" + pct(state.getCurrentDragonHeadChance()) + ", base=" + pct(DragonRewardsMod.CONFIG.dragonHeadBaseChance) + ", inc=" + pct(DragonRewardsMod.CONFIG.dragonHeadFailureIncrement) + ", cap=" + pct(DragonRewardsMod.CONFIG.dragonHeadMaxChance));
        send(src, " Chests: active=" + state.getActiveChests().size() + ", processedDragonIds=" + state.getProcessedDragonCount() + ", debugMode=" + DragonRewardsMod.CONFIG.debugMode);
        return 1;
    }

    private static int reloadConfig(CommandContext<class_2168> ctx) {
        if (!ensureAdmin(ctx.getSource())) {
            return 0;
        }
        DragonRewardsMod.reloadConfig();
        RewardState.get(ctx.getSource().method_9211()).sanitize();
        send(ctx.getSource(), "Reloaded config from disk.");
        return 1;
    }

    private static int saveConfig(CommandContext<class_2168> ctx) {
        if (!ensureAdmin(ctx.getSource())) {
            return 0;
        }
        boolean ok = DragonRewardsMod.saveConfig();
        send(ctx.getSource(), ok ? "Saved config." : "Failed to save config. Check logs.");
        return ok ? 1 : 0;
    }

    private static int setDebug(CommandContext<class_2168> ctx) {
        if (!ensureAdmin(ctx.getSource())) {
            return 0;
        }
        boolean enabled = BoolArgumentType.getBool(ctx, "enabled");
        DragonRewardsMod.CONFIG.debugMode = enabled;
        send(ctx.getSource(), "Debug mode set to " + enabled + ". Use /dragonrewards save to persist.");
        return 1;
    }

    private static int setFeature(CommandContext<class_2168> ctx, boolean elytra) {
        if (!ensureAdmin(ctx.getSource())) {
            return 0;
        }
        boolean enabled = BoolArgumentType.getBool(ctx, "enabled");
        if (elytra) {
            DragonRewardsMod.CONFIG.enableElytraDrops = enabled;
        } else {
            DragonRewardsMod.CONFIG.enableDragonHeadDrops = enabled;
        }
        send(ctx.getSource(), (elytra ? "Elytra" : "Dragon Head") + " drops set to " + enabled + ". Use /dragonrewards save to persist.");
        return 1;
    }

    private static int chanceGet(CommandContext<class_2168> ctx) {
        if (!ensureAdmin(ctx.getSource())) {
            return 0;
        }
        return status(ctx);
    }

    private static int chanceReset(CommandContext<class_2168> ctx, boolean resetElytra, boolean resetHead) {
        if (!ensureAdmin(ctx.getSource())) {
            return 0;
        }
        RewardState state = RewardState.get(ctx.getSource().method_9211());
        if (resetElytra) {
            state.setCurrentElytraChance(DragonRewardsMod.CONFIG.elytraBaseChance);
        }
        if (resetHead) {
            state.setCurrentDragonHeadChance(DragonRewardsMod.CONFIG.dragonHeadBaseChance);
        }
        send(ctx.getSource(), "Reset current chance(s) to base values.");
        return 1;
    }

    private static int chanceSet(CommandContext<class_2168> ctx, boolean elytra) {
        if (!ensureAdmin(ctx.getSource())) {
            return 0;
        }
        double value = DoubleArgumentType.getDouble(ctx, "value");
        RewardState state = RewardState.get(ctx.getSource().method_9211());
        if (elytra) {
            state.setCurrentElytraChance(value);
            send(ctx.getSource(), "Elytra current chance set to " + pct(state.getCurrentElytraChance()) + ".");
        } else {
            state.setCurrentDragonHeadChance(value);
            send(ctx.getSource(), "Dragon Head current chance set to " + pct(state.getCurrentDragonHeadChance()) + ".");
        }
        return 1;
    }

    private static int chanceAdd(CommandContext<class_2168> ctx, boolean elytra) {
        if (!ensureAdmin(ctx.getSource())) {
            return 0;
        }
        double delta = DoubleArgumentType.getDouble(ctx, "delta");
        RewardState state = RewardState.get(ctx.getSource().method_9211());
        if (elytra) {
            state.setCurrentElytraChance(state.getCurrentElytraChance() + delta);
            send(ctx.getSource(), "Elytra current chance is now " + pct(state.getCurrentElytraChance()) + ".");
        } else {
            state.setCurrentDragonHeadChance(state.getCurrentDragonHeadChance() + delta);
            send(ctx.getSource(), "Dragon Head current chance is now " + pct(state.getCurrentDragonHeadChance()) + ".");
        }
        return 1;
    }

    private static int simulate(CommandContext<class_2168> ctx) {
        if (!ensureAdmin(ctx.getSource())) {
            return 0;
        }
        int kills = IntegerArgumentType.getInteger(ctx, "kills");

        double elytraChance = RewardState.get(ctx.getSource().method_9211()).getCurrentElytraChance();
        double headChance = RewardState.get(ctx.getSource().method_9211()).getCurrentDragonHeadChance();
        int elytraDrops = 0;
        int headDrops = 0;

        for (int i = 0; i < kills; i++) {
            if (DragonRewardsMod.CONFIG.enableElytraDrops) {
                if (ThreadLocalRandom.current().nextDouble() < elytraChance) {
                    elytraDrops++;
                    elytraChance = DragonRewardsMod.CONFIG.elytraBaseChance;
                } else {
                    elytraChance = Math.min(DragonRewardsMod.CONFIG.elytraMaxChance, elytraChance + DragonRewardsMod.CONFIG.elytraFailureIncrement);
                }
            }

            if (DragonRewardsMod.CONFIG.enableDragonHeadDrops) {
                if (ThreadLocalRandom.current().nextDouble() < headChance) {
                    headDrops++;
                    headChance = DragonRewardsMod.CONFIG.dragonHeadBaseChance;
                } else {
                    headChance = Math.min(DragonRewardsMod.CONFIG.dragonHeadMaxChance, headChance + DragonRewardsMod.CONFIG.dragonHeadFailureIncrement);
                }
            }
        }

        send(ctx.getSource(), "Simulation over " + kills + " kills (state unchanged):");
        send(ctx.getSource(), " Elytra drops=" + elytraDrops + ", final simulated chance=" + pct(elytraChance));
        send(ctx.getSource(), " Dragon Head drops=" + headDrops + ", final simulated chance=" + pct(headChance));
        return 1;
    }

    private static int listChests(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        if (!ensureAdmin(src)) {
            return 0;
        }
        RewardState state = RewardState.get(src.method_9211());
        List<ActiveRewardChest> chests = state.getActiveChests();
        send(src, "Active reward chests: " + chests.size());
        for (int i = 0; i < chests.size(); i++) {
            ActiveRewardChest chest = chests.get(i);
            send(src, " [" + i + "] owner=" + chest.ownerName() + " pos=" + chest.chestPos().method_23854());
        }
        return 1;
    }

    private static int cleanupChests(CommandContext<class_2168> ctx) {
        if (!ensureAdmin(ctx.getSource())) {
            return 0;
        }
        DragonRewardManager.reconcilePersistentChests(ctx.getSource().method_9211());
        send(ctx.getSource(), "Reconciled persistent reward chests with world state.");
        return 1;
    }

    private static int clearChests(CommandContext<class_2168> ctx) {
        if (!ensureAdmin(ctx.getSource())) {
            return 0;
        }
        class_3218 end = getEndWorld(ctx.getSource());
        if (end == null) {
            send(ctx.getSource(), "The End is not loaded.");
            return 0;
        }
        int removed = DragonRewardManager.removeAllManagedChests(end);
        send(ctx.getSource(), "Removed " + removed + " managed reward chest(s).");
        return 1;
    }

    private static int setChestTime(CommandContext<class_2168> ctx) {
        if (!ensureAdmin(ctx.getSource())) {
            return 0;
        }
        int minutes = IntegerArgumentType.getInteger(ctx, "minutes");
        DragonRewardsMod.CONFIG.rewardClaimTimeMinutes = minutes;
        send(ctx.getSource(), "Reward claim timer set to " + minutes + " minute(s). Use /dragonrewards save to persist.");
        return 1;
    }

    private static int setChestDelay(CommandContext<class_2168> ctx) {
        if (!ensureAdmin(ctx.getSource())) {
            return 0;
        }
        int seconds = IntegerArgumentType.getInteger(ctx, "seconds");
        DragonRewardsMod.CONFIG.rewardSpawnDelaySeconds = seconds;
        send(ctx.getSource(), "Reward chest spawn delay set to " + seconds + " second(s). Use /dragonrewards save to persist.");
        return 1;
    }

    private static int removeChestAt(CommandContext<class_2168> ctx) {
        if (!ensureAdmin(ctx.getSource())) {
            return 0;
        }
        class_3218 end = getEndWorld(ctx.getSource());
        if (end == null) {
            send(ctx.getSource(), "The End is not loaded.");
            return 0;
        }

        int x = IntegerArgumentType.getInteger(ctx, "x");
        int y = IntegerArgumentType.getInteger(ctx, "y");
        int z = IntegerArgumentType.getInteger(ctx, "z");
        class_2338 pos = new class_2338(x, y, z);
        boolean removed = DragonRewardManager.removeManagedChest(end, pos);
        send(ctx.getSource(), removed ? "Removed managed chest at " + pos.method_23854() : "No managed chest found at " + pos.method_23854());
        return removed ? 1 : 0;
    }

    private static int spawnChest(CommandContext<class_2168> ctx) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        if (!ensureAdmin(ctx.getSource())) {
            return 0;
        }
        class_3218 end = getEndWorld(ctx.getSource());
        if (end == null) {
            send(ctx.getSource(), "The End is not loaded.");
            return 0;
        }

        class_3222 player = net.minecraft.class_2186.method_9315(ctx, "player");
        boolean elytra = BoolArgumentType.getBool(ctx, "elytra");
        boolean head = BoolArgumentType.getBool(ctx, "dragon_head");

        class_2338 pos = DragonRewardManager.spawnManualRewardChest(end, player, elytra, head);
        if (pos == null) {
            send(ctx.getSource(), "Nothing spawned. At least one reward must be true.");
            return 0;
        }

        send(ctx.getSource(), "Spawned manual reward chest for " + player.method_5477().getString() + " at " + pos.method_23854());
        return 1;
    }

    private static int processedCount(CommandContext<class_2168> ctx) {
        if (!ensureAdmin(ctx.getSource())) {
            return 0;
        }
        RewardState state = RewardState.get(ctx.getSource().method_9211());
        send(ctx.getSource(), "Processed dragon IDs tracked: " + state.getProcessedDragonCount());
        return 1;
    }

    private static int clearProcessed(CommandContext<class_2168> ctx) {
        if (!ensureAdmin(ctx.getSource())) {
            return 0;
        }
        RewardState state = RewardState.get(ctx.getSource().method_9211());
        state.clearProcessedDragons();
        send(ctx.getSource(), "Cleared processed dragon ID cache.");
        return 1;
    }

    private static class_3218 getEndWorld(class_2168 source) {
        return source.method_9211().method_3847(class_1937.field_25181);
    }

    private static String pct(double chance) {
        return String.format(Locale.ROOT, "%.2f%%", chance * 100.0);
    }

    private static void send(class_2168 source, String message) {
        source.method_9226(() -> DragonRewardsText.commandLine(message), false);
    }
}
