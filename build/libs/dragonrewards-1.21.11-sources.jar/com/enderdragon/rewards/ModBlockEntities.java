package com.enderdragon.rewards;

import com.enderdragon.rewards.block.entity.RewardChestBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModBlockEntities {
    public static class_2591<RewardChestBlockEntity> REWARD_CHEST;

    public static void init() {
        REWARD_CHEST = class_2378.method_10230(
            class_7923.field_41181,
            class_2960.method_60655(DragonRewardsMod.MOD_ID, "reward_chest"),
            FabricBlockEntityTypeBuilder.create(RewardChestBlockEntity::new, ModBlocks.REWARD_CHEST).build()
        );
    }
}
