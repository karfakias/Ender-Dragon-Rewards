package com.enderdragon.rewards;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public final class DragonRewardsText {
    private DragonRewardsText() {
    }

    public static class_5250 commandLine(String message) {
        return class_2561.method_43473()
            .method_10852(class_2561.method_43470("◆ ").method_27695(class_124.field_1064, class_124.field_1067))
            .method_10852(class_2561.method_43470("Dragon Rewards").method_27695(class_124.field_1076, class_124.field_1067))
            .method_10852(class_2561.method_43470(" » ").method_27692(class_124.field_1063))
            .method_10852(class_2561.method_43470(message).method_27692(class_124.field_1080));
    }

    public static class_5250 unauthorized(String ownerName) {
        String raw = DragonRewardsMod.CONFIG.messages.unauthorizedChest.replace("{player}", ownerName);
        return class_2561.method_43473()
            .method_10852(class_2561.method_43470("✖ ").method_27695(class_124.field_1061, class_124.field_1067))
            .method_10852(class_2561.method_43470(raw).method_27692(class_124.field_1061));
    }

    public static class_5250 outcome(String message, OutcomeType type) {
        return class_2561.method_43473()
            .method_10852(class_2561.method_43470(type.symbol + " ").method_27695(type.prefixColor, class_124.field_1067))
            .method_10852(class_2561.method_43470("Dragon Rewards").method_27695(type.prefixColor, class_124.field_1067))
            .method_10852(class_2561.method_43470(" » ").method_27692(class_124.field_1063))
            .method_10852(class_2561.method_43470(message).method_27692(type.messageColor));
    }

    public static class_2561 chestTitle(String ownerName) {
        return class_2561.method_43473()
            .method_10852(class_2561.method_43470("✦ ").method_27695(class_124.field_1076, class_124.field_1067))
            .method_10852(class_2561.method_43470(ownerName + "'s Rewards").method_27695(class_124.field_1075, class_124.field_1067));
    }

    public static class_2561 chestTitleWithTimer(String ownerName, long remainingTicks) {
        return class_2561.method_43473()
            .method_10852(class_2561.method_43470("✦ ").method_27695(class_124.field_1076, class_124.field_1067))
            .method_10852(class_2561.method_43470(ownerName + "'s Rewards").method_27695(class_124.field_1075, class_124.field_1067))
            .method_10852(class_2561.method_43470(" • ").method_27692(class_124.field_1063))
            .method_10852(class_2561.method_43470(formatRemaining(remainingTicks)).method_27695(class_124.field_1065, class_124.field_1067));
    }

    public static String formatRemaining(long remainingTicks) {
        long safe = Math.max(0L, remainingTicks);
        long totalSeconds = safe / 20L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format("%02d:%02d", minutes, seconds);
    }

    public enum OutcomeType {
        NOTHING("☘", class_124.field_1060, class_124.field_1054),
        ELYTRA("✈", class_124.field_1075, class_124.field_1075),
        DRAGON_HEAD("☠", class_124.field_1064, class_124.field_1076),
        BOTH("✦", class_124.field_1065, class_124.field_1065);

        final String symbol;
        final class_124 prefixColor;
        final class_124 messageColor;

        OutcomeType(String symbol, class_124 prefixColor, class_124 messageColor) {
            this.symbol = symbol;
            this.prefixColor = prefixColor;
            this.messageColor = messageColor;
        }
    }
}
