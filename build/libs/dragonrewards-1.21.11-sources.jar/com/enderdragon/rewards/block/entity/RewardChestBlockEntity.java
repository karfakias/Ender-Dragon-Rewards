package com.enderdragon.rewards.block.entity;

import com.enderdragon.rewards.DragonRewardManager;
import com.enderdragon.rewards.DragonRewardsMod;
import com.enderdragon.rewards.ModBlockEntities;
import java.util.UUID;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1278;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4844;

public class RewardChestBlockEntity extends class_2586 implements class_1263, class_1278, net.minecraft.class_3908 {
    private static final int[] NO_SLOTS = new int[0];
    private final class_2371<class_1799> inventory = class_2371.method_10213(27, class_1799.field_8037);

    private UUID ownerUuid;
    private String ownerName = "Unknown";

    public RewardChestBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.REWARD_CHEST, pos, state);
    }

    public void setOwner(UUID ownerUuid, String ownerName) {
        this.ownerUuid = ownerUuid;
        this.ownerName = ownerName;
        method_5431();
    }

    public UUID getOwnerUuid() {
        return ownerUuid;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public boolean canOpen(class_1657 player) {
        return ownerUuid != null && ownerUuid.equals(player.method_5667());
    }

    public class_2561 getUnauthorizedText() {
        String raw = DragonRewardsMod.CONFIG.messages.unauthorizedChest.replace("{player}", ownerName);
        return class_2561.method_43470(raw);
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43470(ownerName + "'s Rewards");
    }

    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        if (!canOpen(player)) {
            return null;
        }
        return class_1707.method_19245(syncId, playerInventory, this);
    }

    @Override
    public int method_5439() {
        return inventory.size();
    }

    @Override
    public boolean method_5442() {
        for (class_1799 stack : inventory) {
            if (!stack.method_7960()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public class_1799 method_5438(int slot) {
        return inventory.get(slot);
    }

    @Override
    public class_1799 method_5434(int slot, int amount) {
        class_1799 stack = class_1262.method_5430(inventory, slot, amount);
        if (!stack.method_7960()) {
            afterInventoryChanged();
        }
        return stack;
    }

    @Override
    public class_1799 method_5441(int slot) {
        class_1799 stack = class_1262.method_5428(inventory, slot);
        afterInventoryChanged();
        return stack;
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        inventory.set(slot, stack);
        if (stack.method_7947() > method_5444()) {
            stack.method_7939(method_5444());
        }
        afterInventoryChanged();
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return canOpen(player);
    }

    @Override
    public void method_5448() {
        inventory.clear();
        afterInventoryChanged();
    }

    @Override
    public int[] method_5494(class_2350 side) {
        return NO_SLOTS;
    }

    @Override
    public boolean method_5492(int slot, class_1799 stack, class_2350 dir) {
        return false;
    }

    @Override
    public boolean method_5493(int slot, class_1799 stack, class_2350 dir) {
        return false;
    }

    @Override
    protected void method_11007(class_11372 view) {
        super.method_11007(view);
        class_1262.method_5426(view, inventory);
        if (ownerUuid != null) {
            view.method_71468("OwnerUuid", class_4844.field_40825, ownerUuid);
        }
        view.method_71469("OwnerName", ownerName);
    }

    @Override
    protected void method_11014(class_11368 view) {
        super.method_11014(view);
        class_1262.method_5429(view, inventory);
        ownerUuid = view.method_71426("OwnerUuid", class_4844.field_40825).orElse(null);
        ownerName = view.method_71428("OwnerName", "Unknown");
    }

    private void afterInventoryChanged() {
        method_5431();
        if (field_11863 instanceof class_3218 serverWorld && method_5442()) {
            DragonRewardManager.onRewardChestEmptied(serverWorld, field_11867);
        }
    }
}
