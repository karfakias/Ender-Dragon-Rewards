package com.enderdragon.rewards.block;

import com.enderdragon.rewards.block.entity.RewardChestBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3908;
import net.minecraft.class_3965;

public class RewardChestBlock extends class_2237 {
    public static final MapCodec<RewardChestBlock> CODEC = method_54094(RewardChestBlock::new);

    public RewardChestBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (world.method_8608()) {
            return class_1269.field_5812;
        }

        class_2586 blockEntity = world.method_8321(pos);
        if (!(blockEntity instanceof RewardChestBlockEntity rewardChest)) {
            return class_1269.field_5811;
        }

        if (!rewardChest.canOpen(player)) {
            class_2561 text = rewardChest.getUnauthorizedText();
            if (text != null) {
                player.method_7353(text, false);
            }
            return class_1269.field_21466;
        }

        class_3908 factory = rewardChest;
        player.method_17355(factory);
        return class_1269.field_21466;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new RewardChestBlockEntity(pos, state);
    }
}
