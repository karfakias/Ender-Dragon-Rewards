package com.enderdragon.rewards;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1799;
import net.minecraft.class_4844;

public record PendingRewardSpawn(UUID ownerUuid, String ownerName, List<class_1799> rewards, long executeAtTick) {
    public static final Codec<PendingRewardSpawn> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        class_4844.field_40825.fieldOf("ownerUuid").forGetter(PendingRewardSpawn::ownerUuid),
        Codec.STRING.fieldOf("ownerName").forGetter(PendingRewardSpawn::ownerName),
        class_1799.field_49266.listOf().fieldOf("rewards").forGetter(PendingRewardSpawn::rewards),
        Codec.LONG.fieldOf("executeAtTick").forGetter(PendingRewardSpawn::executeAtTick)
    ).apply(instance, (ownerUuid, ownerName, rewards, executeAtTick) ->
        new PendingRewardSpawn(ownerUuid, ownerName, new ArrayList<>(rewards), executeAtTick)
    ));
}
