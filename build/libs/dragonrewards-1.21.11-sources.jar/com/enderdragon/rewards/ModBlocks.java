package com.enderdragon.rewards;

import net.minecraft.class_2246;
import net.minecraft.class_2248;

public final class ModBlocks {
    private ModBlocks() {
    }

    // Server-only mode uses a vanilla chest to avoid any client-side content requirement.
    public static final class_2248 REWARD_CHEST = class_2246.field_10034;

    public static void init() {
        // No-op.
    }
}
