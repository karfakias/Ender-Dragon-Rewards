package com.enderdragon.rewards.mixin;

import com.enderdragon.rewards.DragonDamageTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.UUID;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1510;
import net.minecraft.class_1657;
import net.minecraft.class_3218;

@Mixin(class_1510.class)
public class EnderDragonEntityMixin implements DragonDamageTracker {
    @Unique
    private UUID dragonrewards$lastDamagerUuid;

    @Unique
    private String dragonrewards$lastDamagerName = "Unknown";

    @Inject(method = "damage", at = @At("HEAD"))
    private void dragonrewards$captureLastDamager(class_3218 world, class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if (amount <= 0.0f) {
            return;
        }

        class_1297 attacker = source.method_5529();
        if (attacker instanceof class_1657 player) {
            dragonrewards$setLastDamager(player);
            return;
        }

        class_1297 sourceEntity = source.method_5526();
        if (sourceEntity instanceof class_1657 player) {
            dragonrewards$setLastDamager(player);
        }
    }

    @Override
    public void dragonrewards$setLastDamager(class_1657 player) {
        this.dragonrewards$lastDamagerUuid = player.method_5667();
        this.dragonrewards$lastDamagerName = player.method_5477().getString();
    }

    @Override
    public UUID dragonrewards$getLastDamagerUuid() {
        return dragonrewards$lastDamagerUuid;
    }

    @Override
    public String dragonrewards$getLastDamagerName() {
        return dragonrewards$lastDamagerName;
    }
}
