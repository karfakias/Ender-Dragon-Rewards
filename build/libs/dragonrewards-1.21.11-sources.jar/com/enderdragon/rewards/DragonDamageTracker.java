package com.enderdragon.rewards;

import java.util.UUID;
import net.minecraft.class_1657;

public interface DragonDamageTracker {
    void dragonrewards$setLastDamager(class_1657 player);

    UUID dragonrewards$getLastDamagerUuid();

    String dragonrewards$getLastDamagerName();
}
