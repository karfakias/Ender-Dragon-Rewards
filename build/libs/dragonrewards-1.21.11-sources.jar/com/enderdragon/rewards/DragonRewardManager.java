package com.enderdragon.rewards;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1277;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1510;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;
import net.minecraft.class_3917;
import net.minecraft.class_3965;
import net.minecraft.class_747;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

public final class DragonRewardManager {
    private static final long TICKS_PER_MINUTE = 20L * 60L;
    private static final String REWARD_MARKER_TAG = "dragonrewards_reward_marker";

    private DragonRewardManager() {
    }

    public static void init() {
        ServerLivingEntityEvents.AFTER_DEATH.register(DragonRewardManager::onEntityDeath);

        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (world.method_8608()) {
                return true;
            }
            if (isManagedRewardChest((class_3218) world, pos)) {
                player.method_7353(DragonRewardsText.commandLine("Reward chests cannot be broken."), false);
                return false;
            }
            return true;
        });

        UseBlockCallback.EVENT.register(DragonRewardManager::onUseBlock);

        ServerLifecycleEvents.SERVER_STARTED.register(DragonRewardManager::reconcilePersistentChests);
        ServerTickEvents.END_SERVER_TICK.register(DragonRewardManager::onServerTick);
    }

    private static void onEntityDeath(class_1309 entity, class_1282 damageSource) {
        if (!(entity instanceof class_1510 dragon)) {
            return;
        }
        if (!(entity.method_73183() instanceof class_3218 world) || world.method_27983() != class_1937.field_25181) {
            return;
        }

        RewardState state = RewardState.get(world.method_8503());
        UUID dragonUuid = dragon.method_5667();
        if (state.isDragonProcessed(dragonUuid)) {
            debug(world.method_8503(), "Skipped duplicate dragon death event for " + dragonUuid);
            return;
        }
        state.markDragonProcessed(dragonUuid);

        OwnerData owner = resolveOwnerData(dragon, damageSource, world);

        boolean rolledElytra = false;
        boolean rolledHead = false;
        List<class_1799> rewards = new ArrayList<>();

        if (DragonRewardsMod.CONFIG.enableElytraDrops) {
            rolledElytra = world.field_9229.method_43058() < state.getCurrentElytraChance();
            if (rolledElytra) {
                rewards.add(new class_1799(class_1802.field_8833));
                state.setCurrentElytraChance(DragonRewardsMod.CONFIG.elytraBaseChance);
            } else {
                state.setCurrentElytraChance(Math.min(
                    DragonRewardsMod.CONFIG.elytraMaxChance,
                    state.getCurrentElytraChance() + DragonRewardsMod.CONFIG.elytraFailureIncrement
                ));
            }
        }

        if (DragonRewardsMod.CONFIG.enableDragonHeadDrops) {
            rolledHead = world.field_9229.method_43058() < state.getCurrentDragonHeadChance();
            if (rolledHead) {
                rewards.add(new class_1799(class_1802.field_8712));
                state.setCurrentDragonHeadChance(DragonRewardsMod.CONFIG.dragonHeadBaseChance);
            } else {
                state.setCurrentDragonHeadChance(Math.min(
                    DragonRewardsMod.CONFIG.dragonHeadMaxChance,
                    state.getCurrentDragonHeadChance() + DragonRewardsMod.CONFIG.dragonHeadFailureIncrement
                ));
            }
        }

        if (!rewards.isEmpty()) {
            queueDelayedChestSpawn(world, state, owner, rewards);
        }

        broadcastOutcome(world.method_8503(), owner.playerName(), rolledElytra, rolledHead);
    }

    private static void createRewardChest(class_3218 world, RewardState state, class_2338 chestPos, OwnerData owner, List<class_1799> rewards) {
        world.method_8652(chestPos, class_2246.field_10034.method_9564(), class_2248.field_31036);
        clearVanillaChestInventory(world, chestPos);

        long expiresAtTick = world.method_75260() + (DragonRewardsMod.CONFIG.rewardClaimTimeMinutes * TICKS_PER_MINUTE);
        UUID markerUuid = spawnNameMarker(world, chestPos, owner.playerName(), expiresAtTick - world.method_75260());
        List<class_1799> rewardCopies = new ArrayList<>();
        for (class_1799 stack : rewards) {
            if (!stack.method_7960()) {
                rewardCopies.add(stack.method_7972());
            }
        }
        state.addChest(new ActiveRewardChest(owner.playerUuid(), owner.playerName(), chestPos, markerUuid, rewardCopies, expiresAtTick));

        debug(world.method_8503(), "Spawned reward chest for " + owner.playerName() + " at " + chestPos.method_23854());
        long minutes = DragonRewardsMod.CONFIG.rewardClaimTimeMinutes;
        ownerNotifyChest(world, owner, chestPos, minutes);
    }

    private static void queueDelayedChestSpawn(class_3218 world, RewardState state, OwnerData owner, List<class_1799> rewards) {
        long delayTicks = DragonRewardsMod.CONFIG.rewardSpawnDelaySeconds * 20L;
        long executeAt = world.method_8503().method_3847(class_1937.field_25179).method_75260() + delayTicks;
        List<class_1799> copies = new ArrayList<>();
        for (class_1799 stack : rewards) {
            if (!stack.method_7960()) {
                copies.add(stack.method_7972());
            }
        }
        state.addPendingSpawn(new PendingRewardSpawn(owner.playerUuid(), owner.playerName(), copies, executeAt));
    }

    public static class_2338 spawnManualRewardChest(class_3218 world, class_3222 owner, boolean includeElytra, boolean includeDragonHead) {
        if (!includeElytra && !includeDragonHead) {
            return null;
        }

        RewardState state = RewardState.get(world.method_8503());
        class_2338 chestPos = findChestSpawnPosition(world, state);
        List<class_1799> rewards = new ArrayList<>();
        if (includeElytra) {
            rewards.add(new class_1799(class_1802.field_8833));
        }
        if (includeDragonHead) {
            rewards.add(new class_1799(class_1802.field_8712));
        }

        OwnerData ownerData = new OwnerData(owner.method_5667(), owner.method_5477().getString());
        createRewardChest(world, state, chestPos, ownerData, rewards);
        return chestPos;
    }

    public static boolean removeManagedChest(class_3218 world, class_2338 pos) {
        RewardState state = RewardState.get(world.method_8503());
        Optional<ActiveRewardChest> chest = state.getActiveChests().stream()
            .filter(active -> active.chestPos().equals(pos))
            .findFirst();

        if (chest.isEmpty()) {
            return false;
        }

        removeManagedChest(world, state, chest.get());
        return true;
    }

    public static int removeAllManagedChests(class_3218 world) {
        RewardState state = RewardState.get(world.method_8503());
        List<ActiveRewardChest> snapshot = new ArrayList<>(state.getActiveChests());
        for (ActiveRewardChest chest : snapshot) {
            removeManagedChest(world, state, chest);
        }
        return snapshot.size();
    }

    public static void onRewardChestEmptied(class_3218 world, class_2338 pos) {
        RewardState state = RewardState.get(world.method_8503());
        class_3218 resolvedRewardWorld = getRewardWorld(world.method_8503());
        class_3218 rewardWorld = resolvedRewardWorld == null ? world : resolvedRewardWorld;
        Optional<ActiveRewardChest> chest = state.getActiveChests().stream()
            .filter(active -> active.chestPos().equals(pos))
            .findFirst();

        chest.ifPresent(active -> {
            removeManagedChest(rewardWorld, state, active);
            debug(world.method_8503(), "Removed emptied reward chest at " + pos.method_23854());
        });
    }

    public static void reconcilePersistentChests(MinecraftServer server) {
        class_3218 end = server.method_3847(class_1937.field_25181);
        if (end == null) {
            return;
        }

        RewardState state = RewardState.get(server);
        processPendingSpawns(end, state);

        List<ActiveRewardChest> snapshot = new ArrayList<>(state.getActiveChests());
        for (ActiveRewardChest chest : snapshot) {
            class_2338 pos = chest.chestPos();
            class_2680 blockState = end.method_8320(pos);
            if (!blockState.method_27852(class_2246.field_10034)) {
                removeMarker(end, chest.markerUuid(), pos);
                state.removeChestAt(pos);
                continue;
            }
            clearVanillaChestInventory(end, pos);

            class_1297 marker = chest.markerUuid() == null ? null : end.method_66347(chest.markerUuid());
            if (marker instanceof class_1531 armorStand) {
                tagRewardMarker(armorStand);
            } else {
                UUID newMarker = spawnNameMarker(end, pos, chest.ownerName(), chest.expiresAtTick() - end.method_75260());
                state.updateChest(chest.withMarker(newMarker));
            }
        }
        cleanupOrphanRewardMarkers(end, state);
    }

    private static OwnerData resolveOwnerData(class_1510 dragon, class_1282 source, class_3218 world) {
        UUID uuid = null;
        String name = "Unknown";

        if (dragon instanceof DragonDamageTracker tracker) {
            uuid = tracker.dragonrewards$getLastDamagerUuid();
            String trackedName = tracker.dragonrewards$getLastDamagerName();
            if (trackedName != null && !trackedName.isBlank()) {
                name = trackedName;
            }
        }

        if (uuid == null) {
            class_1297 attacker = source.method_5529();
            if (attacker instanceof class_3222 serverPlayer) {
                uuid = serverPlayer.method_5667();
                name = serverPlayer.method_5477().getString();
            }
        }

        if (uuid == null) {
            class_3222 fallback = world.method_18456().stream()
                .min((a, b) -> Double.compare(a.method_5858(dragon), b.method_5858(dragon)))
                .orElse(null);
            if (fallback != null) {
                uuid = fallback.method_5667();
                name = fallback.method_5477().getString();
            }
        }

        if (uuid == null) {
            uuid = new UUID(0L, 0L);
        }

        return new OwnerData(uuid, name);
    }

    private static void broadcastOutcome(MinecraftServer server, String playerName, boolean elytra, boolean dragonHead) {
        String template;
        DragonRewardsText.OutcomeType type;
        if (elytra && dragonHead) {
            template = DragonRewardsMod.CONFIG.messages.bothDropped;
            type = DragonRewardsText.OutcomeType.BOTH;
        } else if (elytra) {
            template = DragonRewardsMod.CONFIG.messages.onlyElytra;
            type = DragonRewardsText.OutcomeType.ELYTRA;
        } else if (dragonHead) {
            template = DragonRewardsMod.CONFIG.messages.onlyDragonHead;
            type = DragonRewardsText.OutcomeType.DRAGON_HEAD;
        } else {
            template = DragonRewardsMod.CONFIG.messages.nothingDropped;
            type = DragonRewardsText.OutcomeType.NOTHING;
        }

        String rendered = template.replace("{player}", playerName);
        broadcastOutcomeThroughTellraw(server, rendered, type);
    }

    private static void broadcastOutcomeThroughTellraw(MinecraftServer server, String message, DragonRewardsText.OutcomeType type) {
        JsonObject root = new JsonObject();
        JsonArray extra = new JsonArray();
        extra.add(tellrawSegment(type.symbol + " ", type.prefixColor, true));
        extra.add(tellrawSegment("Dragon Rewards", type.prefixColor, true));
        extra.add(tellrawSegment(" \u00BB ", class_124.field_1063, false));
        extra.add(tellrawSegment(message, type.messageColor, false));
        root.addProperty("text", "");
        root.add("extra", extra);

        try {
            server.method_3734().method_44252(server.method_3739().method_9217(), "tellraw @a " + root);
        } catch (Exception ex) {
            DragonRewardsMod.LOGGER.warn("Failed to announce reward outcome through tellraw; falling back to direct broadcast.", ex);
            server.method_3760().method_43514(DragonRewardsText.outcome(message, type), false);
        }
    }

    private static JsonObject tellrawSegment(String text, class_124 color, boolean bold) {
        JsonObject segment = new JsonObject();
        segment.addProperty("text", text);
        segment.addProperty("color", color.method_537());
        if (bold) {
            segment.addProperty("bold", true);
        }
        return segment;
    }

    private static class_2338 findChestSpawnPosition(class_3218 world, RewardState state) {
        int centerX = DragonRewardsMod.CONFIG.chestSpawnCenterX;
        int centerZ = DragonRewardsMod.CONFIG.chestSpawnCenterZ;
        int fixedY = DragonRewardsMod.CONFIG.chestSpawnFixedY;
        Set<class_2338> occupied = new HashSet<>();
        for (ActiveRewardChest active : state.getActiveChests()) {
            occupied.add(active.chestPos());
        }

        int radius = Math.max(1, DragonRewardsMod.CONFIG.chestSpawnRadius);
        for (int ring = 0; ring <= radius; ring++) {
            for (int dx = -ring; dx <= ring; dx++) {
                for (int dz = -ring; dz <= ring; dz++) {
                    if (ring != 0 && Math.max(Math.abs(dx), Math.abs(dz)) != ring) {
                        continue;
                    }

                    class_2338 candidate = new class_2338(centerX + dx, fixedY, centerZ + dz);
                    if (!occupied.contains(candidate) && isValidChestSpot(world, candidate)) {
                        return candidate;
                    }
                }
            }
        }

        // Guaranteed fallback within configured area, force-place at fixed Y.
        for (int ring = 0; ring <= radius; ring++) {
            for (int dx = -ring; dx <= ring; dx++) {
                for (int dz = -ring; dz <= ring; dz++) {
                    if (ring != 0 && Math.max(Math.abs(dx), Math.abs(dz)) != ring) {
                        continue;
                    }
                    class_2338 fallback = new class_2338(centerX + dx, fixedY, centerZ + dz);
                    if (!occupied.contains(fallback)) {
                        return fallback;
                    }
                }
            }
        }
        return new class_2338(centerX, fixedY, centerZ);
    }

    private static boolean isValidChestSpot(class_3218 world, class_2338 pos) {
        return world.method_8320(pos).method_26215()
            && world.method_8320(pos.method_10084()).method_26215()
            && world.method_8320(pos.method_10074()).method_26212(world, pos.method_10074());
    }

    private static class_1269 onUseBlock(class_1657 player, class_1937 world, class_1268 hand, class_3965 hitResult) {
        if (world.method_8608() || hand != class_1268.field_5808 || !(world instanceof class_3218 serverWorld)) {
            return class_1269.field_5811;
        }

        class_2338 pos = hitResult.method_17777();
        RewardState state = RewardState.get(serverWorld.method_8503());
        ActiveRewardChest chest = state.getChestAt(pos);
        if (chest == null) {
            return class_1269.field_5811;
        }

        if (!player.method_5667().equals(chest.ownerUuid())) {
            player.method_7353(DragonRewardsText.unauthorized(chest.ownerName()), false);
            return class_1269.field_5814;
        }

        openRewardScreen(serverWorld, (class_3222) player, chest);
        return class_1269.field_5812;
    }

    private static void openRewardScreen(class_3218 world, class_3222 player, ActiveRewardChest chest) {
        class_1277 inventory = new class_1277(27);
        int slot = 0;
        for (class_1799 stack : chest.rewards()) {
            if (slot >= inventory.method_5439()) {
                break;
            }
            inventory.method_5447(slot++, stack.method_7972());
        }

        class_747 factory = new class_747((syncId, playerInventory, opener) ->
            new class_1707(class_3917.field_17326, syncId, playerInventory, inventory, 3) {
                @Override
                public void method_7595(class_1657 closedBy) {
                    super.method_7595(closedBy);
                    updateRewardsFromInventory(world, chest.chestPos(), inventory);
                }

                @Override
                public boolean method_7597(class_1657 user) {
                    return user.method_5667().equals(chest.ownerUuid());
                }
            },
            DragonRewardsText.chestTitleWithTimer(chest.ownerName(), chest.expiresAtTick() - world.method_75260())
        );

        player.method_17355(factory);
    }

    private static void updateRewardsFromInventory(class_3218 world, class_2338 chestPos, class_1277 inventory) {
        RewardState state = RewardState.get(world.method_8503());
        ActiveRewardChest existing = state.getChestAt(chestPos);
        if (existing == null) {
            return;
        }

        List<class_1799> remaining = new ArrayList<>();
        for (int i = 0; i < inventory.method_5439(); i++) {
            class_1799 stack = inventory.method_5438(i);
            if (!stack.method_7960()) {
                remaining.add(stack.method_7972());
            }
        }

        if (remaining.isEmpty()) {
            class_3218 rewardWorld = getRewardWorld(world.method_8503());
            if (rewardWorld == null) {
                rewardWorld = world;
            }
            removeManagedChest(rewardWorld, state, existing);
        } else {
            state.updateChest(existing.withRewards(remaining));
            clearVanillaChestInventory(world, chestPos);
        }
    }

    private static boolean isManagedRewardChest(class_3218 world, class_2338 pos) {
        RewardState state = RewardState.get(world.method_8503());
        return state.getChestAt(pos) != null;
    }

    private static void clearVanillaChestInventory(class_3218 world, class_2338 pos) {
        if (!(world.method_8321(pos) instanceof net.minecraft.class_2595 chestBlockEntity)) {
            return;
        }
        for (int i = 0; i < chestBlockEntity.method_5439(); i++) {
            chestBlockEntity.method_5447(i, class_1799.field_8037);
        }
        chestBlockEntity.method_5431();
    }

    private static UUID spawnNameMarker(class_3218 world, class_2338 chestPos, String ownerName, long remainingTicks) {
        class_1531 marker = class_1299.field_6131.method_5883(world, class_3730.field_16467);
        if (marker == null) {
            return null;
        }

        marker.method_5814(chestPos.method_10263() + 0.5, chestPos.method_10264() + 1.35, chestPos.method_10260() + 0.5);
        marker.method_5648(true);
        marker.method_5875(true);
        marker.method_5880(true);
        marker.method_5665(DragonRewardsText.chestTitleWithTimer(ownerName, remainingTicks));
        marker.method_5684(true);
        tagRewardMarker(marker);

        world.method_8649(marker);
        return marker.method_5667();
    }

    private static void onServerTick(MinecraftServer server) {
        if ((server.method_3780() % 20) != 0) {
            return;
        }
        class_3218 end = server.method_3847(class_1937.field_25181);
        if (end == null) {
            return;
        }

        RewardState state = RewardState.get(server);
        processPendingSpawns(end, state);

        List<ActiveRewardChest> snapshot = new ArrayList<>(state.getActiveChests());
        for (ActiveRewardChest chest : snapshot) {
            long remaining = chest.expiresAtTick() - end.method_75260();
            if (remaining <= 0) {
                removeManagedChest(end, state, chest);
                continue;
            }

            if (!end.method_8320(chest.chestPos()).method_27852(class_2246.field_10034)) {
                end.method_8652(chest.chestPos(), class_2246.field_10034.method_9564(), class_2248.field_31036);
                clearVanillaChestInventory(end, chest.chestPos());
            }

            class_1297 marker = chest.markerUuid() == null ? null : end.method_66347(chest.markerUuid());
            if (marker instanceof class_1531 armorStand) {
                tagRewardMarker(armorStand);
                armorStand.method_5665(DragonRewardsText.chestTitleWithTimer(chest.ownerName(), remaining));
            } else {
                UUID newMarker = spawnNameMarker(end, chest.chestPos(), chest.ownerName(), remaining);
                state.updateChest(chest.withMarker(newMarker));
            }
        }
        if ((server.method_3780() % (20 * 20)) == 0) {
            cleanupOrphanRewardMarkers(end, state);
        }
    }

    private static void processPendingSpawns(class_3218 endWorld, RewardState state) {
        long now = endWorld.method_8503().method_3847(class_1937.field_25179).method_75260();
        List<PendingRewardSpawn> snapshot = new ArrayList<>(state.getPendingSpawns());
        for (PendingRewardSpawn pending : snapshot) {
            if (pending.executeAtTick() > now) {
                continue;
            }

            class_2338 chestPos = findChestSpawnPosition(endWorld, state);
            OwnerData owner = new OwnerData(pending.ownerUuid(), pending.ownerName());
            createRewardChest(endWorld, state, chestPos, owner, pending.rewards());
            state.removePendingSpawn(pending);
        }
    }

    private static void ownerNotifyChest(class_3218 world, OwnerData owner, class_2338 chestPos, long minutes) {
        class_3222 player = world.method_8503().method_3760().method_14602(owner.playerUuid());
        if (player == null) {
            return;
        }
        String message = "Your rewards chest spawned at X=" + chestPos.method_10263() + ", Y=" + chestPos.method_10264() + ", Z=" + chestPos.method_10260()
            + ". You have " + minutes + " minutes to receive your rewards.";
        player.method_7353(DragonRewardsText.commandLine(message), false);
    }

    private static void removeManagedChest(class_3218 world, RewardState state, ActiveRewardChest chest) {
        removeMarker(world, chest.markerUuid(), chest.chestPos());
        removeRewardBlock(world, chest.chestPos());
        state.removeChestAt(chest.chestPos());
    }

    private static void removeRewardBlock(class_3218 world, class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        if (state.method_27852(class_2246.field_10034) || state.method_27852(ModBlocks.REWARD_CHEST)) {
            world.method_8650(pos, false);
        }
    }

    private static void removeMarker(class_3218 world, UUID markerUuid, class_2338 chestPos) {
        if (markerUuid != null) {
            class_1297 entity = world.method_66347(markerUuid);
            if (entity != null) {
                entity.method_31472();
                return;
            }
        }

        if (chestPos != null) {
            removeRewardMarkersNear(world, chestPos);
        }
    }

    private static void removeRewardMarkersNear(class_3218 world, class_2338 chestPos) {
        class_238 markerBox = new class_238(
            chestPos.method_10263() - 0.75D,
            chestPos.method_10264(),
            chestPos.method_10260() - 0.75D,
            chestPos.method_10263() + 1.75D,
            chestPos.method_10264() + 3.25D,
            chestPos.method_10260() + 1.75D
        );
        for (class_1531 marker : world.method_8390(class_1531.class, markerBox, DragonRewardManager::isRewardMarker)) {
            marker.method_31472();
        }
    }

    private static void cleanupOrphanRewardMarkers(class_3218 world, RewardState state) {
        Set<UUID> activeMarkerIds = new HashSet<>();
        for (ActiveRewardChest chest : state.getActiveChests()) {
            if (chest.markerUuid() != null) {
                activeMarkerIds.add(chest.markerUuid());
            }
        }

        int radius = Math.max(1, DragonRewardsMod.CONFIG.chestSpawnRadius) + 3;
        int centerX = DragonRewardsMod.CONFIG.chestSpawnCenterX;
        int centerZ = DragonRewardsMod.CONFIG.chestSpawnCenterZ;
        int fixedY = DragonRewardsMod.CONFIG.chestSpawnFixedY;
        class_238 markerArea = new class_238(
            centerX - radius,
            fixedY,
            centerZ - radius,
            centerX + radius + 1,
            fixedY + 5,
            centerZ + radius + 1
        );

        for (class_1531 marker : world.method_8390(class_1531.class, markerArea, DragonRewardManager::isRewardMarker)) {
            if (activeMarkerIds.contains(marker.method_5667())) {
                tagRewardMarker(marker);
            } else {
                marker.method_31472();
            }
        }
    }

    private static boolean isRewardMarker(class_1531 marker) {
        if (marker.method_5752().contains(REWARD_MARKER_TAG)) {
            return true;
        }
        class_2561 customName = marker.method_5797();
        return customName != null && customName.getString().contains("'s Rewards");
    }

    private static void tagRewardMarker(class_1531 marker) {
        marker.method_5780(REWARD_MARKER_TAG);
    }

    private static class_3218 getRewardWorld(MinecraftServer server) {
        return server.method_3847(class_1937.field_25181);
    }

    private static void debug(MinecraftServer server, String message) {
        if (DragonRewardsMod.CONFIG.debugMode) {
            DragonRewardsMod.LOGGER.info("[debug] {}", message);
        }
    }

    private record OwnerData(UUID playerUuid, String playerName) {
    }
}
